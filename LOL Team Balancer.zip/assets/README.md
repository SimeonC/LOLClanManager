### Assets Readme
This folder contains all style and javascript files to be served up to the user.
### Startup and Security README
This directory has all files relating directly to the starting up of the server(s), also should include in here all global authentication/authorization logic.
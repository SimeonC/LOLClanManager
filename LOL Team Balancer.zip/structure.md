. :	Root level Readme - Notes for the whole project it's structure and intent
./api :	This directory and it's children (if any) contain all the business logic or data driven functions of the application.
./assets :	This folder contains all style and javascript files to be served up to the user.
./startup :	This directory has all files relating directly to the starting up of the server(s).
./test :	This directory is used for testing of functions used elsewhere. This implementation utilises Mocha. To run all tests run: mocha --compilers coffee:coffee-script
./views :	This folder contains all of the files to create the HTML pages that are server to the browser.

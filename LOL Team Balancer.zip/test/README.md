### Tests Readme
This directory is used for testing of functions used elsewhere. This implementation utilises Mocha. To run all tests run: `npm test` or `mocha --compilers coffee:coffee-script`
### Views Readme
This folder contains all of the files to create the HTML pages that are server to the browser.